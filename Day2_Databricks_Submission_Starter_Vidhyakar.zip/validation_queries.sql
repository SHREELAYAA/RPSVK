-- Replace YOUR_SCHEMA with your actual assigned Databricks schema.
SELECT current_user();
SHOW CATALOGS;
SHOW SCHEMAS IN databricks_operations_training;
SHOW TABLES IN databricks_operations_training.YOUR_SCHEMA;
SELECT COUNT(*) AS target_rows FROM databricks_operations_training.YOUR_SCHEMA.sales_orders;
SELECT order_id, COUNT(*) AS occurrences FROM databricks_operations_training.YOUR_SCHEMA.sales_orders GROUP BY order_id HAVING COUNT(*) > 1;
DESCRIBE HISTORY databricks_operations_training.YOUR_SCHEMA.sales_orders;
SELECT order_status, COUNT(*) AS rows FROM databricks_operations_training.YOUR_SCHEMA.sales_orders GROUP BY order_status ORDER BY rows DESC;
SELECT COUNT(*) AS job_output_rows FROM databricks_operations_training.YOUR_SCHEMA.day2_job_output;
-- Run only the appropriate queries after the respective notebook creates each table.
